
public class DefaultPmiIntegrationCegidImportFacade implements PmiIntegrationCegidImportFacade {

    private static final Logger LOG = Logger.getLogger(DefaultPmiIntegrationCegidImportFacade.class);
    private static final String PMI_CEGID_PAYLOAD_VALIDATION_ENABLED = "pmi.cegid.payload.validation.enabled";
    private static final double EPSILON = 0.0001d;
    private static final double EPSILON_ZERO = 0.0000;

    private CommonI18NService commonI18NService;
    private PmiIntegrationCegidImportService pmiIntegrationCegidImportService;
    private PmiSerialNumberService serialNumberService;
    private PmiIntegrationCegidOrderService pmiIntegrationCegidOrderService;
    private DefaultPmiReturnService defaultPmiReturnService;
    private PmiConsumerReturnReasonService pmiConsumerReturnReasonService;

    private AibsPropertyService aibsPropertyService;
    private PmiOrderTypeStrategy orderTypeStrategy;
    @Override
    public void validateImport(CegidPosImportData importData) {
        String receipt = "Receipt number is : '" + importData.getCegidKeyNumber() + "'.";

        CegidImportUtils.assertFalse("Transaction fed has no entries: aborting transaction. " + receipt,
                CollectionUtils.isEmpty(importData.getEntries()));
        CegidImportUtils.assertFalse("Transaction fed has one or more entries that have no EAN (barCode) associated to: aborting transaction. " + receipt,
                importData.getEntries().stream().anyMatch(entry -> StringUtils.isBlank(entry.getBarCode())));
        CegidImportUtils.assertFalse("Transaction fed has Zero entry Quantity : aborting transaction. " + receipt,
                CollectionUtils.isEmpty(importData.getEntries().stream().filter(entry -> entry.getQuantity() > 0).ollect(Collectors.toList())));
    @Override
    public void setPaymentInfoOnAbstractOrder(AbstractOrderModel cart, CegidPosImportData importData) {
        getPmiIntegrationCegidImportService().setPaymentInfoOnAbstractOrder(cart, importData);
    }

    @Override
    public Optional<RefundEntryModel> getRefundEntryModel(Map<String, CegidAggregatedQuantitiesData> aggregatedQuantities, ReturnRequestModel returnRequestModel, AbstractOrderEntryModel orderEntry) {
        return getPmiIntegrationCegidImportService().getRefundEntryModel(aggregatedQuantities, returnRequestModel, orderEntry);
    }

    /**
     * @param importData
     * @param cartModel
     */
    @Override
    public void validateCegidImportData(CegidPosImportData importData, AbstractOrderModel cartModel) throws CegidCartValidationException{
        if(aibsPropertyService.getBoolean(PMI_CEGID_PAYLOAD_VALIDATION_ENABLED,false) && isZTAOrder(cartModel)){
            boolean isValidCegidPayload =checkPriceAndQuantityFromOrderLevel(cartModel, importData) && checkEntriesData(cartModel,importData);
            if(!isValidCegidPayload){
                throw new CegidCartValidationException("Invalid cegid request");
            }
        }
    }
    
    private boolean isZTAOrder(AbstractOrderModel cart) {
        return getOrderTypeStrategy().isZtaOrder(cart);
    }

    private boolean checkPriceAndQuantityFromOrderLevel(AbstractOrderModel cart, CegidPosImportData importData) {
        return checkPrice(cart, importData) && checkQuantities(cart, importData);
    }

    private static boolean checkPrice(AbstractOrderModel cart, CegidPosImportData importData) {
        if (isDoubleEqual(importData.getTaxIncludedTotalAmount(), cart.getSubtotal())) {
            return true;
        } else {
            LOG.info("Total price discrepancies. Cegid total price : " + importData.getTaxIncludedTotalAmount() + " and Hybris total price : " + cart.getSubtotal());
        }
        return false;
    }

    private static boolean isDoubleEqual(Double cart, Double importData) {
        return importData != null && Math.abs(importData - cart) < EPSILON ;
    }

    private boolean checkQuantities(AbstractOrderModel cart, CegidPosImportData importData) {
        if(importData.getTotalQuantity() != null && importData.getTotalQuantity() == PmiOrderUtils.getTotalQuantities(cart)){
            return true;
        } else{
            LOG.info("Quantity discrepancies. Cegid quantity : " + importData.getTotalQuantity() + " and Hybris quantity: " + PmiOrderUtils.getTotalQuantities(cart));
        }
        return false;
    }

    private boolean checkEntriesData(AbstractOrderModel cart, CegidPosImportData importData) {
        for(CegidPosImportEntryData entry : importData.getEntries()){
            boolean isValidEntry = checkEntryData(entry, cart);
            if(!isValidEntry){
                LOG.info("Cart entry level discrepancies and skipping for other entries. Entry number : " +entry.getEntryNumber());
                return isValidEntry;
            }
        }
        return true;
    }

    private boolean checkEntryData(CegidPosImportEntryData entry, AbstractOrderModel cart) {
        AbstractOrderEntryModel entryModel = PmiOrderUtils.getEntryForNumber(cart, entry.getEntryNumber());
        if(entryModel != null){
            return checkQuantity(entry, entryModel) && checkVariant(entry, entryModel) && checkTotalPrice(entry, entryModel) && checkDiscount(entry, entryModel);
        } else {
            LOG.info("Cart entry not found . Entry Number " + entry.getEntryNumber());
        }
        return false;
    }

    private static boolean checkDiscount(CegidPosImportEntryData entry, AbstractOrderEntryModel entryModel) {
        if((entry.getItemDiscountNet() == null || Math.abs(entry.getItemDiscountNet() -EPSILON_ZERO) < EPSILON) && CollectionUtils.isEmpty(entryModel.getDiscountValues())){
            return true;
        }
        if(entry.getItemDiscountNet() != null && CollectionUtils.isNotEmpty(entryModel.getDiscountValues())){
            double discountOnCartEntry = entryModel.getDiscountValues().stream().mapToDouble(DiscountValue::getAppliedValue).sum();
            if(Math.abs(entry.getItemDiscountNet() -discountOnCartEntry) < EPSILON ){
                return true;
            }else {
                LOG.info("Entry level discount discrepancies . Cegid entry discount : " + entry.getItemDiscountNet() + "and Hybris entry discount : " + discountOnCartEntry);
            }
        }
        return false;
    }

    private static boolean checkTotalPrice(CegidPosImportEntryData entry, AbstractOrderEntryModel entryModel) {
        if(entry.getTaxIncludedNetUnitPrice() != null && entryModel.getTotalPrice() != null && isDoubleEqual(entry.getTaxIncludedNetUnitPrice(), entryModel.getTotalPrice())){
            return true;
        } else {
            LOG.info("Entry level price discrepancies . Cegid entry price : " + entry.getTaxIncludedNetUnitPrice() + "and Hybris entry price : " + entryModel.getTotalPrice());
        }
        return false;
    }

    private static boolean checkVariant(CegidPosImportEntryData entry, AbstractOrderEntryModel entryModel) {
       if(entry.getBarCode() != null && entryModel.getProduct().getEan().equals(entry.getBarCode())){
           return true;
       } else {
           LOG.info("Entry level variant discrepancies . Cegid entry variant : " + entry.getBarCode() + "and Hybris entry variant : " + entryModel.getProduct().getEan());
       }
       return false;
    }

    private static boolean checkQuantity(CegidPosImportEntryData entry, AbstractOrderEntryModel entryModel) {
       if(entry.getQuantity() != null && entryModel.getQuantity() != null && entry.getQuantity().longValue() == entryModel.getQuantity().longValue()){
           return true;
       } else {
           LOG.info("Entry level quantity discrepancies . Cegid entry qunatity : " + entry.getQuantity() + " and Hybris entry quantity : " + entryModel.getQuantity());
       }
       return false;
    }


