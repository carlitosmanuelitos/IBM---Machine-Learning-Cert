
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings("ignore")

# Define the date
date = "24-03-2024"

# Define the output folder and file name
output_folder = f"Work/Visualization/Graphs/{date}"
data_folder = "Work/Visualization/Data/Not Exported"
input_file_name = f"Order_Not_Exported_{date}.csv"

# Construct the full paths
input_file_path = os.path.join(data_folder, input_file_name)
output_path = os.path.join(output_folder)

# Create the directory if it does not exist
if not os.path.exists(output_path):
    os.makedirs(output_path)


def create_plots(df, output_path):
    # Create the output folder if it doesn't exist
    os.makedirs(output_path, exist_ok=True)
    current_date = datetime.now()
    print(f"Initial dataframe shape: {df.shape}")
    df['UPDATE DATE'] = pd.to_datetime(df['UPDATE DATE'].str.split().str[0], format='%d/%m/%Y', errors='coerce')
    df.dropna(subset=['UPDATE DATE'], inplace=True)
    print(f"dataframe shape after removing issues UPDATE DATE: {df.shape}")

    # Sort by 'UPDATE DATE' and drop duplicates, keeping only the last occurrence
    df.sort_values('UPDATE DATE', inplace=True)
    df.drop_duplicates(subset='ORDER CODE', keep='last', inplace=True)
    print(f"dataframe shape after removing duplicate orders: {df.shape}")


    df['ORDER AGE'] = (current_date.date() - df['UPDATE DATE'].dt.date).apply(lambda x: x.days)
    df['AGE CATEGORY'] = df['ORDER AGE'].apply(lambda x: 'Under 30 days' if x < 30 else 'Over 30 days')


    # Unique Count - Grouped
    grouped_data = df.groupby(['COUNTRY', 'PMI ORDER STATUS'])['ORDER CODE'].nunique().reset_index()
    relevant_statuses = ['CREATED', 'PROCESSED', 'RECEIVED', 'SHIPPED']
    filtered_data = grouped_data[grouped_data['PMI ORDER STATUS'].isin(relevant_statuses)]
    total_stuck_orders = filtered_data['ORDER CODE'].sum()

    # Over vs Under - Grouped
    grouped_data_vs = df.groupby(['COUNTRY', 'PMI ORDER STATUS', 'AGE CATEGORY'])['ORDER CODE'].nunique().reset_index()
    relevant_statuses_vs = ['CREATED', 'PROCESSED', 'RECEIVED', 'SHIPPED']
    filtered_data_vs = grouped_data_vs[grouped_data_vs['PMI ORDER STATUS'].isin(relevant_statuses_vs)]
    total_stuck_orders_vs = filtered_data_vs['ORDER CODE'].sum()

    # ------------- Graphs1. Individual STATUS -------------
    # Create subplots for each order status
    fig, axes = plt.subplots(2, 2, figsize=(14, 8.5))
    fig.suptitle('Count of Order Per Country Per Status')
    
    for i, status in enumerate(relevant_statuses):
        filtered_status_data = filtered_data[filtered_data['PMI ORDER STATUS'] == status]
        filtered_status_data.sort_values(by='ORDER CODE', ascending=False, inplace=True)

        row, col = divmod(i, 2)
        ax = sns.barplot(x='COUNTRY', y='ORDER CODE', data=filtered_status_data, ax=axes[row, col], palette='viridis')
        ax.set_title(f'Orders in {status} Status')
        ax.set_xlabel('Country')
        ax.set_ylabel('Unique Order Count')
        ax.set_xticklabels(ax.get_xticklabels(), rotation=45)
        ax.grid(axis='y', linestyle='--', alpha=0.7)  # Add grid lines

        # Add count labels on top of each bar
        for p in ax.patches:
                ax.annotate(f'{int(p.get_height())}', (p.get_x() + p.get_width() / 2., p.get_height()), ha='center', va='bottom')


        # Add percentage text within the graph (relative to total stuck orders)
        percentage = filtered_status_data['ORDER CODE'].sum() / total_stuck_orders * 100
        ax.annotate(f'Total: {percentage:.1f}%', xy=(0.5, 0.95), xycoords='axes fraction', ha='center', fontsize=12)

    plt.tight_layout()
    plt.savefig(os.path.join(output_path, 'Stuck Order Count.png'))
    plt.show()    

    # ------------- Graphs2. Over & Under STATUS -------------
    # Create subplots for each order status
    fig, axes = plt.subplots(2, 2, figsize=(14, 8.5))
    fig.suptitle('Over vs Under 30 days Per Country Per Status')

    for i, status in enumerate(['CREATED', 'PROCESSED', 'RECEIVED', 'SHIPPED']):
        filtered_status_data_vs = grouped_data_vs[grouped_data_vs['PMI ORDER STATUS'] == status]
        filtered_status_data_vs.sort_values(by='ORDER CODE', ascending=False, inplace=True)

        row, col = divmod(i, 2)
        ax = sns.barplot(x='COUNTRY', y='ORDER CODE', hue='AGE CATEGORY', data=filtered_status_data_vs, ax=axes[row, col], palette='coolwarm')
        ax.set_title(f'Orders in {status} Status')
        ax.set_xlabel('Country')
        ax.set_ylabel('Unique Order Count')
        ax.set_xticklabels(ax.get_xticklabels(), rotation=45)
        ax.grid(axis='y', linestyle='--', alpha=0.7)  # Add grid lines

        # Add count labels on top of each bar
        for p in ax.patches:
            ax.annotate(f'{int(p.get_height())}', (p.get_x() + p.get_width() / 2., p.get_height()), ha='center', va='bottom')

        print(f"filtered_status_data_vs['ORDER CODE'].sum(): {filtered_status_data_vs['ORDER CODE'].sum()}")
        print(f'total_stuck_orders_vs: {total_stuck_orders_vs}')
        try:
            percentage = filtered_status_data_vs['ORDER CODE'].sum() / total_stuck_orders_vs * 100
        except ZeroDivisionError:
            percentage = 0
        ax.annotate(f'Total: {percentage:.1f}%', xy=(0.5, 0.95), xycoords='axes fraction', ha='center', fontsize=12)

    plt.tight_layout()
    plt.savefig(os.path.join(output_path, 'Over-Under 30 days.png'))
    plt.show()


df = pd.read_csv(input_file_path, sep=";")
create_plots(df, output_folder)