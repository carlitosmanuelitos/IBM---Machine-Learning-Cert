import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import seaborn as sns


date = "22-03-2024"
specific_dates = ["2024-03-08", "2024-03-15", "2024-03-22"]

# Define the output folder and file name
output_folder = f"Work/Visualization/Graphs/{date}"
data_directory = "Work/Visualization/Data/Orders"
output_file_name = "Stuck_Order_Evolution.png"
output_path = os.path.join(output_folder, output_file_name)

# Create the directory if it does not exist
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Filter data for the specific dates
specific_dates_dt = pd.to_datetime(specific_dates)
csv_files = [file for file in os.listdir(data_directory) if file.lower().endswith(".csv")]
combined_df = pd.DataFrame()

# Read data from each CSV file and append to combined_df
for file in csv_files:
    extraction_date = os.path.splitext(file)[0].split("_")[-1]  # Extract the date from the file name
    extraction_date = pd.to_datetime(extraction_date, format="%d-%m-%Y")  # Convert to datetime format
    if extraction_date in specific_dates_dt:
        df = pd.read_csv(os.path.join(data_directory, file), sep=";")
        df["Extraction Date"] = extraction_date
        combined_df = combined_df._append(df, ignore_index=True)

# Group data by country, order status, and extraction date
grouped_data = combined_df.groupby(["COUNTRY", "PMI ORDER STATUS", "Extraction Date"])["ORDER CODE"].count().reset_index()

# Plotting
fig, axes = plt.subplots(2, 2, figsize=(14, 8.5))
fig.suptitle('Order Trend by Status')

order_statuses = ["CREATED", "RECEIVED", "PROCESSED", "SHIPPED"]
for i, status in enumerate(order_statuses):
    status_data = grouped_data[grouped_data["PMI ORDER STATUS"] == status]
    agg_data = status_data.groupby(['COUNTRY', 'Extraction Date'])['ORDER CODE'].sum().reset_index()
    
    row, col = divmod(i, 2)
    for country in agg_data["COUNTRY"].unique():
        country_data = agg_data[agg_data["COUNTRY"] == country]
        axes[row, col].plot(country_data["Extraction Date"], country_data["ORDER CODE"], marker="o", label=country)
        
    axes[row, col].yaxis.set_major_locator(ticker.MaxNLocator(integer=True))
    axes[row, col].set_title(f'Orders in {status} Status')
    axes[row, col].set_xlabel('Extraction Date')
    axes[row, col].set_ylabel('Order Count')
    axes[row, col].set_xticks(specific_dates_dt)
    axes[row, col].legend(title="Country")
    axes[row, col].grid(axis='y', linestyle='--', alpha=0.7)

plt.tight_layout()
plt.savefig(output_path)
plt.show()
print(f"File saved successfully at: {output_path}")
