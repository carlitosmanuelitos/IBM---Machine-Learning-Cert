import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import seaborn as sns


date = "24-03-2024"
specific_dates = ["2024-03-24", "2024-03-26"]

# Define the output folder and file name
output_folder = f"Work/Visualization/Graphs/{date}"
data_directory = "Work/Visualization/Data/Not Exported"
output_file_name = "Not_Exported_Order_Evolution.png"
output_path = os.path.join(output_folder, output_file_name)

# Create the directory if it does not exist
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Filter data for the specific dates
specific_dates_dt = pd.to_datetime(specific_dates)
csv_files = [file for file in os.listdir(data_directory) if file.lower().endswith(".csv")]
combined_df = pd.DataFrame()

# Read data from each CSV file and append to combined_df
for file in csv_files:
    extraction_date = os.path.splitext(file)[0].split("_")[-1]  # Extract the date from the file name
    extraction_date = pd.to_datetime(extraction_date, format="%d-%m-%Y")  # Convert to datetime format
    if extraction_date in specific_dates_dt:
        df = pd.read_csv(os.path.join(data_directory, file), sep=";")
        df["Extraction Date"] = extraction_date
        combined_df = combined_df._append(df, ignore_index=True)

# Group data by country, order status, and extraction date
grouped_data = combined_df.groupby(["COUNTRY", "PMI ORDER STATUS", "Extraction Date"])["ORDER CODE"].count().reset_index()


# Create the plot
plt.figure(figsize=(14, 8.5))
plt.suptitle('Not Exported Orders Trend')

# Plot data for 'CREATED' status
for country in grouped_data["COUNTRY"].unique():
    country_data = grouped_data[grouped_data["COUNTRY"] == country]
    plt.plot(country_data["Extraction Date"], country_data["ORDER CODE"], marker="o", label=country)

# Customize the plot
plt.gca().yaxis.set_major_locator(ticker.MaxNLocator(integer=True))
plt.title('Orders in CREATED Status')
plt.xlabel('Extraction Date')
plt.ylabel('Order Count')
plt.xticks(pd.to_datetime(specific_dates))  # Ensure specific_dates is a list of date strings
plt.legend(title="Country")
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Save the plot to the specified output path
output_folder = "Work/Visualization/Graphs/24-03-2024"
output_file_name = "Created_Order_Evolution.png"
output_path = os.path.join(output_folder, output_file_name)
plt.tight_layout()
plt.savefig(output_path)
plt.show()
print(f"File saved successfully at: {output_path}")






