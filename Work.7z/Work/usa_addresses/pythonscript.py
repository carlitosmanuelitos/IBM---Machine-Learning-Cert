import json

# Load the data from the JSON file
with open(r'C:\Users\mhlopes\Documents\Coursera Courses\IBM Machine Learning Professional Certificate\Work\USA_addresses_3k.json') as f:
    data = json.load(f)

# Retrieve 'address1' fields
address1_list = [address['address1'] for address in data['addresses']]

# Create a dictionary with id's, original address, and character count for each address
address_length = {i: {"address": address, "length": len(address)} for i, address in enumerate(address1_list)}

# Write to a new JSON file
with open(r'Work\address_length.json', 'w') as f:
    json.dump(address_length, f, indent=4)

# Create a list of id's where the length of the address is larger than 50 characters
address_length_exceeded = [i for i, address in enumerate(address1_list) if len(address) > 50]

# Write to a new JSON file
with open(r'Work\address_length_exceeded.json', 'w') as f:
    json.dump(address_length_exceeded, f, indent=4)
